
<?php
$penyakit = [
    "Antraks" => ["G01", "G02", "G003"],
    "Penyakit Mulut dan Kuku (PMK)" => ["G04", "G07", "G08", "G10", "G11", "G14", "G16"],
    "Bovine Ephemeral Fever (BEF)" => ["G16", "G17", "G18"],
    "Mastitis" => [ "G25", "G24"],
    "Salmonellosis" => ["G28", "G29", "G34","G30","G31","G32","G33",],
    "Pink Eye" => ["G22", "G23"],
    "Trypanosomiasis (Penyakit Mubeng)" => ["G07", "G08", "G09"],
    "Malignant Catarrhal Fever (MCF) / Penyakit Ingusan" => ["G10", "G11", "G12", "G13"],
    "Scabies (Budug, Manga, Kudis Menular)" => ["G14", "G15"],
    "Helminthiasis (Cacingan)" => ["G19", "G20", "G21"],
    "Brucellosis (Keluron Menular)" => ["G26", "G27"],
    "Septichaemia Epizootica (SE / Ngorok)" => ["G04", "G05", "G06"]
];

$solusi = [
    "Antraks" => "Isolasi ternak yang terinfeksi, pemberian antibiotik seperti penisilin atau oksitetrasiklin, serta vaksinasi rutin untuk mencegah penyebaran. Jika ditemukan kasus kematian mendadak, segera laporkan ke pihak berwenang dan lakukan pembakaran atau penguburan bangkai sesuai protokol biosekuriti karena spora bakteri sangat tahan di lingkungan.",
    "Penyakit Mulut dan Kuku (PMK)" => "Isolasi hewan yang sakit, desinfeksi kandang dan peralatan dengan larutan formalin atau NaOH, pemberian antiseptik pada luka mulut dan kuku, serta pemberian vitamin untuk mempercepat pemulihan.",
    "Bovine Ephemeral Fever (BEF)" => "Pemberian antipiretik seperti flunixin untuk menurunkan demam, suplemen vitamin B kompleks dan C, pengawasan ketat terhadap kondisi tubuh sapi, serta dukungan nutrisi untuk mempercepat pemulihan. Gejala khas seperti kelemahan ekstremitas dan turunnya produksi susu pada sapi menyusui juga perlu ditangani dengan istirahat cukup dan cairan.",
    "Mastitis" => "Pemberian antibiotik secara lokal (intramammary) dan sistemik, serta menjaga kebersihan ambing sebelum dan sesudah pemerahan menggunakan larutan antiseptik. Penanganan gejala seperti ambing bengkak dan perubahan fisik susu dilakukan dengan segera untuk mencegah kerusakan permanen.",
    "Salmonellosis" => "Pemberian antibiotik seperti enrofloxacin dan terapi rehidrasi menggunakan oralit atau infus, isolasi hewan sakit, serta penerapan sanitasi ketat pada kandang dan peralatan.",
    "Pink Eye" => "Terapkan antibiotik topikal seperti tetes mata oksitetrasiklin dan antibiotik sistemik jika perlu, serta hindari paparan debu dan lalat dengan menjaga kebersihan lingkungan dan menggunakan jaring pelindung. Gejala khas seperti mata berair, kemerahan, dan keruh pada kornea perlu ditangani segera agar tidak terjadi kebutaan.",
    "Trypanosomiasis (Penyakit Mubeng)" => "Pemberian obat antiparasit seperti diminazen aceturate atau isometamidium, eliminasi vektor penyebar seperti lalat tsetse, serta meningkatkan daya tahan tubuh sapi dengan pemberian vitamin dan nutrisi tambahan.",
    "Malignant Catarrhal Fever (MCF) / Penyakit Ingusan" => "Isolasi ternak yang menunjukkan gejala, pemberian terapi suportif seperti antipiretik dan antibiotik sekunder, serta peningkatan daya tahan tubuh dengan pemberian vitamin. Tidak ada pengobatan spesifik, pencegahan dilakukan dengan membatasi kontak dengan hewan pembawa virus seperti domba.",
    "Scabies (Budug, Manga, Kudis Menular)" => "Mandikan hewan dengan larutan insektisida seperti amitraz atau sulfur, lakukan pencukuran rambut di area yang terinfeksi, bersihkan dan desinfeksi kandang, serta isolasi hewan yang terinfeksi agar tidak menularkan ke ternak lain.",
    "Helminthiasis (Cacingan)" => "Beri obat cacing (anthelmintik) seperti albendazole atau ivermectin sesuai dosis, lakukan perbaikan manajemen pakan dan kebersihan, serta hindari penggembalaan di padang rumput yang terkontaminasi untuk mencegah infeksi ulang.",
    "Brucellosis (Keluron Menular)" => "Isolasi hewan yang mengalami keguguran atau gejala reproduksi, lakukan pengujian serologis secara berkala, eliminasi hewan positif, vaksinasi ternak betina yang belum bunting, dan lakukan biosekuriti serta sanitasi kandang untuk mencegah penularan lebih lanjut.",
    "Septichaemia Epizootica (SE / Ngorok)" => "Segera isolasi hewan yang menunjukkan gejala seperti air liur berlebih, gemetar, batuk, dan badan kurus. Berikan antibiotik spektrum luas seperti streptomisin atau oksitetrasiklin. Jaga kebersihan kandang, hindari stres pada ternak, dan lakukan vaksinasi sebagai tindakan pencegahan."
];
?>
