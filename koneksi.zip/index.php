<?php include 'data_gejala.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Diagnosa Penyakit Sapi</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div style="text-align: center; margin-bottom: 1rem;">
    <img src="icow_logo.png" alt="iCow Logo" style="max-height: 200px;">
  </div>
  <h1>Sistem Pakar Diagnosa Penyakit Sapi</h1>
  <form method="post" action="proses.php">
    <h2>Pilih Gejala yang Dialami Sapi:</h2>
    <div class="gejala-list">
      <?php foreach ($gejala as $kode => $nama): ?>
        <label><input type="checkbox" name="gejala[]" value="<?= $kode ?>"> <?= "$kode - $nama" ?></label><br>
      <?php endforeach; ?>
    </div>
    <button type="submit">Diagnosa</button>
  </form>
</body>
</html>
