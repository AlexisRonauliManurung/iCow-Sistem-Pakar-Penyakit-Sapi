<?php
include 'data_gejala.php';
include 'data_penyakit.php';
include 'koneksi.php';

$gejala_input = $_POST['gejala'] ?? [];
$hasil = [];

foreach ($penyakit as $nama => $aturan) {
    $intersect = array_intersect($aturan, $gejala_input);
    $match = count($intersect);
    $total = count($aturan);
    $persentase = round(($match / $total) * 100);

    if ($persentase > 0) {
        $hasil[$nama] = $persentase;
    }
}

arsort($hasil);

$gejala_terpilih = implode(", ", $gejala_input);
$top = array_key_first($hasil);
$persen = $hasil[$top];

mysqli_query($koneksi, "INSERT INTO hasil_diagnosa (gejala_terpilih, penyakit, persentase)
VALUES ('$gejala_terpilih', '$top', $persen)");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Hasil Diagnosa</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    #chart-container {
      position: relative;
      width: 100%;
      max-width: 400px;
      margin: auto;
      height: 250px;
    }
  </style>
</head>
<body>
  <h1>Hasil Diagnosa</h1>
  <?php if (empty($hasil)): ?>
    <p>Tidak ditemukan penyakit berdasarkan gejala yang dipilih.</p>
  <?php else: ?>
    <div id="chart-container">
      <canvas id="chartHasil"></canvas>
    </div>
    <script>
      const ctx = document.getElementById('chartHasil').getContext('2d');
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: [<?= json_encode($top) ?>],
          datasets: [{
            label: 'Persentase Kecocokan (%)',
            data: [<?= json_encode($persen) ?>],
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              max: 100
            }
          }
        }
      });
    </script>

    <p><strong>Penyakit Tertinggi:</strong> <?= $top ?></p>
    <p><strong>Persentase Kecocokan:</strong> <?= $persen ?>%</p>
    <p><strong>Solusi Penanganan:</strong> <?= $solusi[$top] ?></p>
  <?php endif; ?>
</body>
</html>
